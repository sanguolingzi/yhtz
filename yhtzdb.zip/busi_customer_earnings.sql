INSERT INTO `busi_customer_earnings` VALUES (1, 100100, 600.00, 100111, '2018-10-5');
INSERT INTO `busi_customer_earnings` VALUES (2, 100120, 9900.00, 100127, '2018-10-8');
INSERT INTO `busi_customer_earnings` VALUES (3, 100120, 9900.00, 100129, '2018-10-8');
INSERT INTO `busi_customer_earnings` VALUES (4, 100127, 9900.00, 100130, '2018-10-9');
INSERT INTO `busi_customer_earnings` VALUES (5, 100120, 9900.00, 100131, '2018-10-9');
