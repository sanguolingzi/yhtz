INSERT INTO `busi_sys_intf_pattern` VALUES ('/**', 'ALL', 'USER', 01, '2018-9-4 16:35:47');
