INSERT INTO `busi_sys_dictionary` VALUES (1, '账户协议', '1', 'PROTOCOL_TYPE', 1, '2018-4-26 17:01:59', NULL, '2018-4-26 05:00:33', NULL, 0);
INSERT INTO `busi_sys_dictionary` VALUES (2, '网络协议', '2', 'PROTOCOL_TYPE', 2, '2018-4-26 05:01:01', NULL, '2018-4-26 05:01:01', NULL, 0);
INSERT INTO `busi_sys_dictionary` VALUES (3, '五折区活动', '1', 'ACTIVITY_TYPE', NULL, '2018-10-20 10:00:19', NULL, '2018-10-20 10:00:19', '活动名称', 0);
INSERT INTO `busi_sys_dictionary` VALUES (4, '未使用', '0', 'VOUCHER_STATUS', NULL, '2018-11-1 10:28:36', 1, '2018-11-1 10:28:36', '兑换券状态', 0);
INSERT INTO `busi_sys_dictionary` VALUES (5, '已使用', '1', 'VOUCHER_STATUS', NULL, '2018-11-1 10:28:37', 1, '2018-11-1 10:28:37', '兑换券状态', 0);
INSERT INTO `busi_sys_dictionary` VALUES (6, '已过期', '2', 'VOUCHER_STATUS', NULL, '2018-11-1 10:28:37', 1, '2018-11-1 10:28:37', '兑换券状态', 0);
INSERT INTO `busi_sys_dictionary` VALUES (7, '首充礼包兑换券', '1', 'VOUCHER_TYPE', NULL, '2018-11-1 10:28:47', NULL, '2018-11-1 10:28:47', '兑换券类型', 0);
INSERT INTO `busi_sys_dictionary` VALUES (8, '中奖商品兑换券', '2', 'VOUCHER_TYPE', NULL, '2018-11-1 10:28:47', NULL, '2018-11-1 10:28:47', '兑换券类型', 0);
