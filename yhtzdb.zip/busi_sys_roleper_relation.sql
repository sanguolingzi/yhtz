INSERT INTO `busi_sys_roleper_relation` VALUES (1, 1, 1, 0);
INSERT INTO `busi_sys_roleper_relation` VALUES (2, 2, 2, 0);
INSERT INTO `busi_sys_roleper_relation` VALUES (5, 4, 3, 0);
INSERT INTO `busi_sys_roleper_relation` VALUES (6, 5, 4, 0);
INSERT INTO `busi_sys_roleper_relation` VALUES (7, 7, 5, 0);
INSERT INTO `busi_sys_roleper_relation` VALUES (7, 4, 6, 0);
INSERT INTO `busi_sys_roleper_relation` VALUES (4, 3, 7, 0);
