INSERT INTO `busi_sys_advertisement_detail` VALUES (1, 1, 'back/advertisementImgPath/2018110111132832791254846.jpg', NULL, 0, NULL, 0, 1, 0, 2, '2018-11-1 11:13:31', 2, NULL);
INSERT INTO `busi_sys_advertisement_detail` VALUES (2, 2, 'back/advertisementImgPath/2018110111140536626165173.jpg', NULL, 0, NULL, 0, 2, 0, 2, '2018-11-1 11:14:07', 2, NULL);
INSERT INTO `busi_sys_advertisement_detail` VALUES (3, 3, 'back/advertisementImgPath/2018110111141594026384647.jpg', NULL, 0, NULL, 0, 3, 0, 2, '2018-11-1 11:14:17', 2, NULL);
INSERT INTO `busi_sys_advertisement_detail` VALUES (4, 4, 'back/advertisementImgPath/2018110111142546754649414.jpg', NULL, 0, NULL, 0, 4, 0, 2, '2018-11-1 11:14:27', 2, NULL);
