INSERT INTO `busi_customer_yiyuan_relation` VALUES (1, 100127, 2, 12, '2018-10-8 09:58:28');
INSERT INTO `busi_customer_yiyuan_relation` VALUES (2, 100129, 2, 2, '2018-10-8 16:23:19');
INSERT INTO `busi_customer_yiyuan_relation` VALUES (3, 100130, 2, 2, '2018-10-9 17:24:47');
INSERT INTO `busi_customer_yiyuan_relation` VALUES (4, 100131, 2, 8, '2018-10-9 17:45:43');
