INSERT INTO `busi_sys_permission` VALUES (1, '最高权限', 5, '2018-5-7 08:34:31', 5, '2018-5-7 08:34:31', 0);
INSERT INTO `busi_sys_permission` VALUES (2, '运营权限', 5, '2018-5-7 08:35:22', 5, '2018-5-7 08:35:22', 0);
INSERT INTO `busi_sys_permission` VALUES (3, '财务权限', 6, '2018-5-13 22:35:17', 6, '2018-5-13 22:35:17', 0);
INSERT INTO `busi_sys_permission` VALUES (4, '商品管理', 1, '2018-8-15 09:35:37', 1, '2018-8-15 09:35:37', 0);
INSERT INTO `busi_sys_permission` VALUES (5, '代发店铺权限', 1, '2018-8-27 15:31:44', 1, '2018-8-27 15:31:44', 0);
INSERT INTO `busi_sys_permission` VALUES (6, '订单管理', 1, '2018-9-27 14:30:17', 1, '2018-9-27 14:30:17', 0);
INSERT INTO `busi_sys_permission` VALUES (7, '商城订单管理权限', 1, '2018-9-27 14:31:17', 1, '2018-9-27 14:31:17', 0);
