INSERT INTO `busi_sys_channel` VALUES ('CC0001', '123456', 'PC端', 01, '2018-5-2 15:43:46');
INSERT INTO `busi_sys_channel` VALUES ('CC0002', '1234656', 'Android', 01, '2018-5-4 05:49:40');
INSERT INTO `busi_sys_channel` VALUES ('CC0003', '123', 'IOS', 01, '2018-5-4 05:50:40');
INSERT INTO `busi_sys_channel` VALUES ('CC1001', 'nbiZo9sLArvY0U6rVPP96jSEMoDI4EDE', '友棋游戏', 01, '2018-5-24 14:32:29');
INSERT INTO `busi_sys_channel` VALUES ('CC1002', 'UTZDFaA6XoIi0sqhDQp6xjr4AfchhpEo', '棋牌游戏', 01, '2018-5-24 14:33:29');
