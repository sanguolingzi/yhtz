INSERT INTO `busi_customer_collector` VALUES (1, 0, 973, 0, 100101, '2018-10-11 10:59:01', NULL);
INSERT INTO `busi_customer_collector` VALUES (2, 0, 985, 0, 100101, '2018-10-11 10:59:08', NULL);
INSERT INTO `busi_customer_collector` VALUES (3, 0, 398, 0, 100101, '2018-10-11 10:59:15', NULL);
INSERT INTO `busi_customer_collector` VALUES (4, 0, NULL, 1, 100152, '2018-10-24 16:15:48', 1345);
INSERT INTO `busi_customer_collector` VALUES (5, 0, NULL, 1, 100152, '2018-10-24 16:23:38', 1345);
INSERT INTO `busi_customer_collector` VALUES (6, 0, 1345, 0, 100152, '2018-10-24 16:23:59', NULL);
INSERT INTO `busi_customer_collector` VALUES (7, 0, 1345, 0, 100169, '2018-10-27 10:20:13', NULL);
INSERT INTO `busi_customer_collector` VALUES (8, 0, 333, 0, 100169, '2018-10-27 11:46:45', NULL);
