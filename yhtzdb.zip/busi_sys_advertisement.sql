INSERT INTO `busi_sys_advertisement` VALUES (1, '品牌手机', 0, 1, 0, 2, '2018-11-1 11:09:45', 2, NULL);
INSERT INTO `busi_sys_advertisement` VALUES (2, '家纺', 0, 2, 0, 2, '2018-11-1 11:11:47', 2, NULL);
INSERT INTO `busi_sys_advertisement` VALUES (3, '家用电器', 0, 3, 0, 2, '2018-11-1 11:12:20', 2, NULL);
INSERT INTO `busi_sys_advertisement` VALUES (4, '五折区', 0, 4, 0, 2, '2018-11-1 11:13:09', 2, NULL);
