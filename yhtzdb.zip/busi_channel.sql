INSERT INTO `busi_channel` VALUES (1, '会员礼包', 4, '/memberArea', 'back/channel/2018081311240046586279953.png', 0, 2, '2018-8-13 11:24:08', 2, '2018-8-15 16:47:36', 1, 7, '');
INSERT INTO `busi_channel` VALUES (2, '一元购', 3, '/oneYuanRegion', 'back/channel/2018081311241646738831526.png', 0, 2, '2018-8-13 11:24:21', 2, '2018-8-15 16:47:35', 1, 6, '');
INSERT INTO `busi_channel` VALUES (3, '敬请期待', 1, '', 'back/channel/2018081516141728844905500.png', 0, 2, '2018-8-13 11:24:38', 2, '2018-8-15 16:47:34', 1, 0, '');
INSERT INTO `busi_channel` VALUES (4, '友旗麻将', 2, '', 'back/channel/2018081311244773246289825.png', 0, 2, '2018-8-13 11:24:58', 2, '2018-8-15 16:47:32', 1, 0, '');
INSERT INTO `busi_channel` VALUES (5, '首充礼包', 1, '/memberArea', 'back/channel/2018102615030745586405656.png', 0, 2, '2018-8-15 16:48:08', 2, '2018-10-26 15:03:19', 0, 7, '');
INSERT INTO `busi_channel` VALUES (6, '五折专区', 3, '/vip', 'back/channel/2018102615033937691825902.png', 0, 2, '2018-8-15 16:50:30', 2, '2018-10-26 15:03:42', 0, 10, '');
INSERT INTO `busi_channel` VALUES (7, '旗豆购买', 2, '/floorClassList?name=旗豆购买专区&id=8', 'back/channel/2018102615291856955914874.png', 0, 2, '2018-8-15 16:50:54', 2, '2018-10-26 15:29:22', 0, 8, 'name=旗豆购买专区&id=8');
INSERT INTO `busi_channel` VALUES (8, 'U币兑换', 4, '/noviceArea', 'back/channel/2018102615034867281717273.png', 0, 2, '2018-8-15 16:51:16', 2, '2018-10-26 15:03:50', 0, 11, '');
