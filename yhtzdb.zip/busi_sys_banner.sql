INSERT INTO `busi_sys_banner` VALUES (1, '/goodsDetails?id=201', 3, 0, 'back/banner/2018092017530580630425753.jpg', '2018-8-13 11:18:06', '2018-9-21 17:38:19', 2, 2, 0, '家纺', '家纺', 0, 0, 1, 'id=201');
INSERT INTO `busi_sys_banner` VALUES (2, '', 1, 0, 'back/banner/2018091010511543448848404.jpg', '2018-8-13 11:20:08', '2018-9-12 09:05:55', 2, 2, 1, '友旗麻将', '友旗麻将', 0, 0, 0, '');
INSERT INTO `busi_sys_banner` VALUES (3, '/goodsDetails?id=811', 2, 0, 'back/banner/2018092017525638644178178.jpg', '2018-8-13 11:20:33', '2018-9-21 17:38:16', 2, 2, 0, 'RAY面膜', 'RAY面膜', 0, 0, 1, 'id=811');
INSERT INTO `busi_sys_banner` VALUES (4, NULL, 1, 0, 'back/banner/2018091117353717797123214.png', '2018-9-11 17:36:59', '2018-9-12 09:41:01', 1, 1, 1, '测试banner', '测试banner', 0, 0, 0, NULL);
INSERT INTO `busi_sys_banner` VALUES (5, 'floorClassList?id=7', 1, 0, 'back/banner/2018092017285864085618556.jpg', '2018-9-20 17:29:45', '2018-9-21 17:38:13', 2, 2, 0, '欢聚盛典', '欢聚盛典', 0, 0, 9, 'id=7');
INSERT INTO `busi_sys_banner` VALUES (6, '/memberArea', 1, 1, 'back/banner/2018092115314321776475472.jpg', '2018-9-21 15:31:56', '2018-9-21 17:38:07', 2, 2, 1, '即将上线', '即将上线', 0, 0, 7, '');
INSERT INTO `busi_sys_banner` VALUES (7, '/goodsDetails?id=224', 4, 0, 'back/banner/2018092117333126752281163.jpg', '2018-9-21 17:34:44', '2018-9-21 17:38:22', 2, 2, 0, '华帝电烤箱', '华帝电烤箱', 0, 0, 1, 'id=224');
