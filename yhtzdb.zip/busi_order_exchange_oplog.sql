INSERT INTO `busi_order_exchange_oplog` VALUES (1, '2018-9-26 10:59:50', 1, 5, 1, 0, 1);
INSERT INTO `busi_order_exchange_oplog` VALUES (2, '2018-9-26 11:11:03', 1, 5, 2, 0, 2);
INSERT INTO `busi_order_exchange_oplog` VALUES (3, '2018-9-26 11:33:50', 1, 5, 3, 0, 2);
INSERT INTO `busi_order_exchange_oplog` VALUES (4, '2018-10-29 15:15:37', 1, 5, 4, 0, 2);
