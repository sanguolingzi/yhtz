INSERT INTO `busi_sys_role` VALUES (1, '超级管理员', '2018-5-7 08:34:21', 5, '2018-5-7 08:34:21', 5, 0);
INSERT INTO `busi_sys_role` VALUES (2, '运营人员', '2018-5-7 08:35:12', 5, '2018-5-7 08:35:12', 5, 0);
INSERT INTO `busi_sys_role` VALUES (3, '测试', '2018-5-13 22:34:38', 6, '2018-5-13 22:34:38', 6, 0);
INSERT INTO `busi_sys_role` VALUES (4, '财务人员', '2018-5-13 22:35:06', 6, '2018-5-23 09:23:54', 6, 0);
INSERT INTO `busi_sys_role` VALUES (5, '商品管理员', '2018-8-15 09:35:16', 1, '2018-8-15 09:35:16', 1, 0);
INSERT INTO `busi_sys_role` VALUES (6, '代理店铺', '2018-8-27 15:30:22', 1, '2018-9-12 11:53:06', 1, 0);
INSERT INTO `busi_sys_role` VALUES (7, '商城订单管理员', '2018-9-27 14:29:55', 1, '2018-9-27 14:30:59', 1, 0);
